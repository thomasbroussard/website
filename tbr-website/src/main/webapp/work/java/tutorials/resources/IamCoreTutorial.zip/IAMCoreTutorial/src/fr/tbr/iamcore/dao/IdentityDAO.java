package fr.tbr.iamcore.dao;

import java.util.List;
import fr.tbr.iamcore.identity.Identity;

/**
 * Handles the storage of Identity objects
 * @author Tom
 */
public interface IdentityDAO {
	
	/**
	 * Allows to store the given identity
	 * @param identity
	 * @return true if the storage has been successful
	 */
	public boolean store(Identity identity);
	
	/**
	 * Retrieve all the stored identities
	 * @return a List of identities
	 */
	public List<Identity> getAllIdentities();

}
