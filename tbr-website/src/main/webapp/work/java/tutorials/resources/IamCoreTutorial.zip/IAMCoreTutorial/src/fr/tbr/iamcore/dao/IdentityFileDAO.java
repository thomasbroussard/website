package fr.tbr.iamcore.dao;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import fr.tbr.iamcore.identity.Identity;

public class IdentityFileDAO implements IdentityDAO{

	
	private int resolveId(){
		int result = 0;
		File file = new File("/identities/sequence.txt");
		if (!file.exists()) {
			try {
				file.createNewFile();
				FileWriter writer = new FileWriter(file);
				writer.write("1");
				writer.close();

			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			return 1;
		}

		try {
			Scanner scanner = new Scanner(new FileReader(file));
			result = scanner.nextInt();
			scanner.close();
			FileWriter writer = new FileWriter(file);
			int newId = result +1;
			writer.write(String.valueOf(newId));
			writer.close();
			
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return result;
	}
	
	@Override
	public boolean store(Identity identity) {
		File file = new File("/identities/idlist.txt");
		try {
			if (!file.exists()){
				file.createNewFile();
			}
			// append mode
			FileWriter fileWriter = new FileWriter(file, true);
			PrintWriter writer = new PrintWriter(fileWriter, true);
			writer.println("---Begin Identity---");
			writer.println(resolveId());
			writer.println(identity.getDisplayName());
			writer.println(identity.getEmail());
			writer.println("---End Identity---");
			writer.close();
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return true;

		

	}

	@Override
	public List<Identity> getAllIdentities() {
		List<Identity> list = new ArrayList<Identity>();
		try {
			Scanner scanner = new Scanner(new FileReader("/identities/idlist.txt"));
			while(scanner.hasNext()){
				Identity currentIdentity = new Identity();
				String string = scanner.nextLine();
				currentIdentity.setId(scanner.nextLong());
				scanner.nextLine();
				currentIdentity.setDisplayName(scanner.nextLine());

				currentIdentity.setEmail(scanner.nextLine());
				list.add(currentIdentity);
				scanner.nextLine();
			}
			scanner.close();
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return list;
		

	}

}
