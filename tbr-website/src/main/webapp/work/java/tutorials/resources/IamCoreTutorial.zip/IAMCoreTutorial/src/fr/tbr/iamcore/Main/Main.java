package fr.tbr.iamcore.Main;

import java.util.Scanner;

import fr.tbr.iamcore.authentication.Authenticator;
import fr.tbr.iamcore.dao.IdentityDAO;
import fr.tbr.iamcore.dao.IdentityFileDAO;
import fr.tbr.iamcore.identity.Identity;
import fr.tbr.iamcore.logging.IamLog;

public class Main {

	public static void main(String[] args) {
		IamLog logger = new IamLog("Main");

		IdentityDAO identityDAO = new IdentityFileDAO();
		
		logger.log("Beginning of the program", "INFO");
		Scanner scan = new Scanner(System.in);

		System.out
				.println("Welcome to the application, please provide a couple (user name / login)");
		System.out.println("user name:");

		String userName = scan.next();

		System.out.println("password:");

		String password = scan.next();

		Authenticator authenticator = new Authenticator();

		logger.log("try to authenticate the user with this couple " + userName
				+ " / " + password);
		boolean isAuthenticated = authenticator
				.authenticate(userName, password);

		if (isAuthenticated) {
			System.out.println("You were granted");
		} else {
			System.out.println("Not allowed or unknown");
			return;
		}

		logger.log("The user was successfully authenticated, continuing the program");

		System.out
				.println("Would you like to Create (1) , Update (2) , or Delete (3) an Identity in the IAM System?");
		System.out.println("Your choice (1, 2 or 3)");
		try {
			Integer choice = scan.nextInt();
			System.out.println("Your choice was " + choice);
		} catch (Exception e) {
			logger.log("there was an error during the input phase");
			logger.log(e.getMessage());
			System.out
					.println("Your input was not recognized, so please try again.");
			return;

		}

		// Continue proceed to the next step
		//Usage of the dao
		//identityDAO.store(new Identity("id-01","testid","test@test.com" ));
		
		// Get Identities information from the console, create a new object with that
		
/* ----------------- To continue, inspire from that -----------------------
			Identity identity = new Identity();
			System.out.println("Identity Creation Menu");
			System.out.print("display name: ");
			identity.setDisplayName(scanner.nextLine());

			System.out.print("email: ");
			identity.setEmail(scanner.nextLine());
			System.out.println("Confirmation, this Identity : " + identity
					+ " will be created, confirm? (y/n)");
			String confirmation = scanner.next();
			if ("y".equals(confirmation)) {
				if (dao.store(identity)){
					System.out.println("succesfully created!");
				}
			}

*/

	}

}
