package fr.tbr.iamcore.identity;

public class Identity {
	long id;

	private String displayName;
	private String uid;
	private String email;

	public Identity(String displayName, String uid, String email) {
		this.displayName = displayName;
		this.uid = uid;
		this.email = email;
	}

	public Identity() {
	}

	public String getDisplayName() {
		return displayName;
	}

	public void setDisplayName(String displayName) {
		if (displayName == null) {
			// the null is not a valid value
		}
		this.displayName = displayName;
	}

	public String getUid() {
		return uid;
	}

	public void setUid(String uid) {
		this.uid = uid;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public void setId(long id) {
		this.id = id;

	}

	public long getId() {
		return id;
	}

}
