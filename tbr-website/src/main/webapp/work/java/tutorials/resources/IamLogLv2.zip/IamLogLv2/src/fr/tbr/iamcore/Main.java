package fr.tbr.iamcore;

import fr.tbr.iamcore.logging.IamLog;
import fr.tbr.iamcore.logging.IamLog.Level;

public class Main {

	public static void main(String[] args) {
		//... 
		IamLog logger = new IamLog(Main.class.getSimpleName());
		logger.debug("a sample debug test");
		//... next code
		
		logger.log("a sample", Level.INFO);
		logger.log("a good sample", Level.WARN);
	}

}
