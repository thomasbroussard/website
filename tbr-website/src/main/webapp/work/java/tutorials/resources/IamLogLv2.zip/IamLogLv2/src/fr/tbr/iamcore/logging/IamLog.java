package fr.tbr.iamcore.logging;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.text.SimpleDateFormat;
import java.util.Date;

/**
 * The logger for the IAM Log
 * 
 * @author Tom
 */
public class IamLog {

//	public static final String INFO = "INFO";
//	public static final String WARN = "WARN";
//	public static final String DEBUG = "DEBUG";
//	public static final String ERROR = "ERROR";
//	
	/**
	 * Levels for the logging feature
	 * @author Tom
	 *
	 */
	public enum Level{
		INFO,
		WARN,
		DEBUG,
		ERROR
	}
	
	static final SimpleDateFormat sdf = new SimpleDateFormat("yyyy/MM/dd - HH:mm:ss.SSS");
	private String loggingEntity;
	private PrintWriter writer;

	/**
	 * Creates an instance of the logger with the given parameter as a
	 * "logging entity".
	 * 
	 * @param loggingEntity
	 */
	public IamLog(String loggingEntity) {
		File loggingFile = new File("/logs/iamcore.log");
		if (!loggingFile.exists()){ // test if the file is really existing on the file system
			try{
				//try to create the file if it does not exist
				loggingFile.createNewFile();
			}catch(IOException ioe){
				//IOException is the standard exception when you have problem while accessing
				//to a physical system resource
				System.out.println("An error occured while preparing the log file");
			}
		}
		try {
			this.writer = new PrintWriter(new FileWriter(loggingFile));		
			writer.println("Created an IamLog instance, beginning of the log file");
			writer.flush();
		} catch (IOException e) {
			//Could not write in the file
		}
		this.loggingEntity = loggingEntity;
	}

	/**
	 * Output a log entry composed of the message and the level parameter
	 * 
	 * <pre>
	 * <code>
	 * The call log("Hello all", "INFO");
	 * </code>
	 * </pre>
	 * 
	 * will output: {the current date} - [INFO] - Hello all
	 * 
	 * @param message
	 *            the message you want to output
	 * @param level
	 *            the importance of the message
	 */
	public void log(String message, Level level) {
		String trace = sdf.format(new Date()) + " " + loggingEntity + " - ["	+ level + "] - " + message;
		//old call : System.out.println(trace);
		//new call:
		this.writer.println(trace);
		writer.flush();

	}

	/**
	 * output an INFO message
	 * 
	 * @param message
	 *            the message to record
	 */
	public void info(String message) {
		log(message, Level.INFO);
	}

	/**
	 * output an WARN message
	 * 
	 * @param message
	 *            the message to record
	 */
	public void warn(String message) {
		log(message, Level.WARN);
	}

	/**
	 * output an ERROR message
	 * 
	 * @param message
	 *            the message to record
	 */
	public void error(String message) {
		log(message, Level.ERROR);
	}

	/**
	 * output a DEBUG message
	 * 
	 * @param message
	 *            the message to record
	 */
	public void debug(String message) {
		log(message, Level.DEBUG);
	}

}
