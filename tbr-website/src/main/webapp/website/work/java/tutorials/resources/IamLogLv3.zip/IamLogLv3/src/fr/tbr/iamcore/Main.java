package fr.tbr.iamcore;

import fr.tbr.iamcore.logging.IamLog;

/**
 * The main entry point of the identity program
 * 
 * @author Tom
 * 
 */
public class Main {

	public static void main(String[] args) {

		IamLog log = IamLog.getLogger(Main.class);
		log.debug("essai");
	}

}
