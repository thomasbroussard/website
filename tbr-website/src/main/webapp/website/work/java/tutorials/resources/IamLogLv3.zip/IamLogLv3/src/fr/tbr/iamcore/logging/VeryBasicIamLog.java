package fr.tbr.iamcore.logging;

public class VeryBasicIamLog {

}
