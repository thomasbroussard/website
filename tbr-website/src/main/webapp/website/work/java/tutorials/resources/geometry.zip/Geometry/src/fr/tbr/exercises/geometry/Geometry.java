package fr.tbr.exercises.geometry;

public class Geometry {

	public static void main(String[] args) {
		
		Circle smallCircle = new Circle(20);
		Circle bigCircle = new Circle(60);
		
		System.out.println("Small circle perimeter : " + smallCircle.getPerimeter() + ", area : " + smallCircle.getArea());
		System.out.println("Big circle perimeter : " + bigCircle.getPerimeter() + ", area : " + bigCircle.getArea());
		

	}

}
