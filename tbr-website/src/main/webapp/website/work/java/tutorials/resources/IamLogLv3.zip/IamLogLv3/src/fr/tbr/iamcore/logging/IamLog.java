package fr.tbr.iamcore.logging;

import java.util.logging.Level;
import java.util.logging.Logger;

public abstract class IamLog {

	protected Logger logger;
	protected String className;
	
	
	
	public static IamLog getLogger(Class<?> clazz){
		String className = clazz.getName();
		IamLog log = new BasicIamLog(clazz.getName());
		log.className = className;
		return log;
	}
	
	

	private static String getMethodName() {
		final StackTraceElement[] ste = Thread.currentThread().getStackTrace();
		StackTraceElement stackTraceElement = ste[ste.length - 1];
		if (stackTraceElement == null ){
			return "";
		}
		return stackTraceElement.getMethodName() + "()[" +stackTraceElement.getLineNumber()+"]" ; 
	}
	
	public void info (String message){
		
		this.logger.logp(Level.INFO, className, getMethodName(), message);
	}
	
	public void debug (String message){
		this.logger.finest(message);
	}
	
	public void warning (String message){
		this.logger.finest(message);
	}
	
	public void log(String message){
		
	}



	public void error(String message) {
		this.logger.logp(Level.SEVERE, className, getMethodName(), message);
		
	}
	public void error(String message, Throwable th) {
		this.logger.logp(Level.SEVERE, className, getMethodName(), message, th);
		
	}
	
}
