package fr.tbr.iamcore.logging;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.logging.LogRecord;
import java.util.logging.SimpleFormatter;

public class BasicIamFormatter extends SimpleFormatter {
	private static String lf = System.getProperty("line.separator"); 
	
	public static SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy/MM/dd - HH:mm:ss.SSS");

	@Override
	public synchronized String format(LogRecord record) {
		Date date = new Date(record.getMillis());
		
		return simpleDateFormat.format(date) + " : " + record.getSourceClassName() + "."
				+ record.getSourceMethodName() + " : [" + record.getLevel() + "] " 
				+ record.getMessage()+ lf;

	}

}
