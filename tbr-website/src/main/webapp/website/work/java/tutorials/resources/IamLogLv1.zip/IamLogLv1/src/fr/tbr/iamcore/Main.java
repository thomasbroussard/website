package fr.tbr.iamcore;

import fr.tbr.iamcore.logging.IamLog;

public class Main {

	public static void main(String[] args) {
		//... 
		IamLog logger = new IamLog(Main.class.getSimpleName());
		logger.debug("a sample debug test");
		//... next code

	}

}
