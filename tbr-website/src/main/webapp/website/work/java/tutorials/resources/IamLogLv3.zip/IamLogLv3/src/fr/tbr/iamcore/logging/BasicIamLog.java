package fr.tbr.iamcore.logging;

import java.io.File;
import java.io.IOException;
import java.util.logging.FileHandler;
import java.util.logging.Logger;

public class BasicIamLog extends IamLog{
	

	public BasicIamLog(String className){
		this.logger = Logger.getLogger(className);

		try {
			
			FileHandler fh = new FileHandler("C:/logs/log.txt");
			fh.setFormatter(new BasicIamFormatter());
			this.logger.addHandler(fh);
		} catch (SecurityException | IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		
		//this.logger.addHandler(new ConsoleHandler());
	}
	

	
	
}
