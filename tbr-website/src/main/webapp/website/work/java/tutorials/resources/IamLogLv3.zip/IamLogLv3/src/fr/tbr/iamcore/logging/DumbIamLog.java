package fr.tbr.iamcore.logging;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class DumbIamLog extends IamLog {

	private static SimpleDateFormat sdf = new SimpleDateFormat("yyyy/MM/dd - HH:mm:ss.SSS");
	
	
	public DumbIamLog() {
		manipulateFile("C:/logs/log.txt");
	}
	
	public void log(String message) {
		Date date = new Date();
		String datePart = sdf.format(date);
		String result = datePart + " : " + message;
		System.out.println(result);
	}
	
	@Override
	public void info(String message) {
		// TODO Auto-generated method stub
		log("[INFO]" + message);
	}
	
	/**
	* This is a sample log class
	*/
	public void manipulateFile(String path) {
		try {
		    final File pathDir = new File(path);
		//The exists() method return true if the file is found
		    if (!pathDir.exists()) {
				//the mkdirs() method creates the missing directories
				pathDir.mkdirs();
		    }
		//The file object takes the path as a String parameter
		//Notice the File.separator constant: it is used to
		// call the built-in path separator of the system
		    final File file = new File(path + File.separator
					+ sdf.format(new Date())
					+ ".txt");
		    if (!file.exists()) {
				file.createNewFile();
		    }

		//The FileWriter is a writer allowing to write to a file
		    final FileWriter writer = new FileWriter(file);
		//If you want to have more useful methods like
		// "newLine()", you have to use the BufferedWriter class
//		    this.fileWriter = new BufferedWriter(writer);
//			this.fileWriter.write(builder.toString());
//		    this.fileWriter.newLine();

		//the flush method allows to write concretely in the file
//		    this.fileWriter.flush();

		} catch (final IOException e) {
		    e.printStackTrace();
		}
	}
	

}
