package fr.tbr.iamcore.logging;

import java.text.SimpleDateFormat;
import java.util.Date;

/**
 * The logger for the IAM Log
 * 
 * @author Tom
 */
public class IamLog {

	static final SimpleDateFormat sdf = new SimpleDateFormat("yyyy/MM/dd - HH:mm:ss.SSS");
	private String loggingEntity;

	/**
	 * Creates an instance of the logger with the given parameter as a
	 * "logging entity".
	 * 
	 * @param loggingEntity
	 */
	public IamLog(String loggingEntity) {
		this.loggingEntity = loggingEntity;
	}

	/**
	 * Output a log entry composed of the message and the level parameter
	 * 
	 * <pre>
	 * <code>
	 * The call log("Hello all", "INFO");
	 * </code>
	 * </pre>
	 * 
	 * will output: {the current date} - [INFO] - Hello all
	 * 
	 * @param message
	 *            the message you want to output
	 * @param level
	 *            the importance of the message
	 */
	public void log(String message, String level) {
		String trace = sdf.format(new Date()) + " " + loggingEntity + " - ["	+ level + "] - " + message;
		System.out.println(trace);

	}

	/**
	 * output an INFO message
	 * 
	 * @param message
	 *            the message to record
	 */
	public void info(String message) {
		log(message, "INFO");
	}

	/**
	 * output an WARN message
	 * 
	 * @param message
	 *            the message to record
	 */
	public void warn(String message) {
		log(message, "WARN");
	}

	/**
	 * output an ERROR message
	 * 
	 * @param message
	 *            the message to record
	 */
	public void error(String message) {
		log(message, "ERROR");
	}

	/**
	 * output a DEBUG message
	 * 
	 * @param message
	 *            the message to record
	 */
	public void debug(String message) {
		log(message, "DEBUG");
	}

}
